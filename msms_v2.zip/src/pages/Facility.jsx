import React from 'react';
import Header from '../components/Header';
// import ContactHero from '../components/contact/ContactHero';
// import Contactus from '../components/contact/ContactUs';
import Footer from '../components/Footer';
import FacilityHero from '../components/facilities/FacilityHero';
import FacilitiesSection from '../components/facilities/FacilitiesSection';
import WorkProcess from '../components/facilities/WorkProcess';
import FacilityImage from '../components/facilities/FacilityImages';
import ECAClasses from '../components/facilities/EcaClasses';
import TransportFacilities from '../components/facilities/TransportFacilities';
const Facility = () => {
  return (
    <>
      <Header />
<FacilityHero/>
<FacilitiesSection/>
      <WorkProcess/>
      <ECAClasses/>
      <TransportFacilities/>
      <FacilityImage/>
{/* <Contactus/> */}
<Footer/>
</>
  );
};

export default Facility;