import React from 'react';
import Header from '../components/Header';
import AcademicHero from '../components/academics/AcademicHero';
import AcademicExcellence from '../components/academics/AcademicExcellence';
import Footer from '../components/Footer';

const Academic = () => {
  return (
    <>
      <Header />
<AcademicHero/>
<AcademicExcellence/>
<Footer/>
</>
  );
};

export default Academic;