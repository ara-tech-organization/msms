import React from 'react';
import AboutHero from '../components/about/Hero';
import Header from '../components/Header';
import AboutUs from '../components/about/AboutUs';
import StatsCounter from '../components/about/Counter';
import Courses from '../components/about/Courses';
import Instructors from '../components/about/Instructors';
import Footer from '../components/Footer';

const About = () => {
  return (
    <>
      <Header />
<AboutHero/>
<AboutUs/>
<StatsCounter/>
<Courses/>
<Instructors/>
<Footer/>
    </>
  );
};

export default About;
