import React from 'react';
import Header from '../components/Header';
import HeroSection from '../components/home/HeroSection';
import AboutSection from '../components/home/AboutSection';
import ChooseUs from '../components/home/ChooseUs';
import Footer from '../components/Footer'
import Counter from '../components/home/Counter';
import Facilities from '../components/home/StaffPortalSection';
import FaqAccordion from '../components/home/Faq';
import CoreValues from '../components/home/CoreValues';

const Home = () => {
  return (
    <>
      <Header />
      <main>
       <HeroSection/>
       <AboutSection/>
       <Facilities/>
       <CoreValues/>
       <ChooseUs/>
       {/* <Counter/> */}
       <FaqAccordion/>
       <Footer/>
      </main>
    </>
  );
};

export default Home;
