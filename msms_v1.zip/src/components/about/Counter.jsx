import React from 'react';
import CountUp from 'react-countup';
import styles from './Counter.module.css';
import { FaUserGraduate, FaChalkboardTeacher, FaSmile, FaUsers, FaQuoteLeft } from 'react-icons/fa';

const statsData = [
  { icon: <FaUserGraduate />, value: 3000, suffix: '+', label: 'Successfully Trained' },
  { icon: <FaChalkboardTeacher />, value: 15000, suffix: '+', label: 'Classes Completed' },
  { icon: <FaSmile />, value: 97000, suffix: '+', label: 'Satisfaction Rate' },
  { icon: <FaUsers />, value: 102000, suffix: '+', label: 'Students Community' },
];

const testimonials = [
  {
    quote: 'Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    name: 'Kathy Sullivan',
    title: 'CEO at Ordinat It',
  },
  {
    quote: 'Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    name: 'Elsie Stroud',
    title: 'CEO at Edwards',
  },
  {
    quote: 'Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    name: 'Kathy Sullivan',
    title: 'CEO at Ordinat It',
  },
];

const StatsAndTestimonials = () => {
  return (
    <section className={styles.wrapper}>

      {/* STATS COUNTER */}
      <div className={styles.statsContainer}>
        {statsData.map((item, index) => (
          <div key={index} className={styles.statItem}>
            <div className={styles.iconWrapper}>{item.icon}</div>
            <div className={styles.statText}>
              <h3 className={styles.value}>
                <CountUp end={item.value} duration={3} separator="," />{item.suffix}
              </h3>
              <p className={styles.label}>{item.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* TESTIMONIAL SECTION */}
      <div className={styles.testimonialSection}>
        <p className={styles.subheading}>Testimonial</p>
        <h2 className={styles.heading}>Creating A Community Of Life Long Learners.</h2>

        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial, index) => (
            <div key={index} className={styles.testimonialCard}>
              <FaQuoteLeft className={styles.quoteIcon} />
              <p className={styles.quote}>{testimonial.quote}</p>
              <h4 className={styles.name}>{testimonial.name}</h4>
              <p className={styles.title}>{testimonial.title}</p>
            </div>
          ))}
        </div>
      </div>

    </section>
  );
};

export default StatsAndTestimonials;
