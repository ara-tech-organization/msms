import React from 'react';
import styles from './AboutUs.module.css';

const AboutUs = () => {
  return (
    <section className={styles.aboutUs}>
      <div className={styles.leftSide}>
        {/* Decorative green image */}
        <img
          src="./images/green.png"
          alt="Decoration"
          className={styles.decor}
        />

        {/* Main Girl Image */}
        <img
          src="./images/stu-1.png"
          alt="Student Standing"
          className={styles.mainImage}
        />

        {/* Right two blocks */}
        <div className={styles.rightBlocks}>
          <div className={styles.yearsBox}>
            <h2>35+</h2>
            <p>Years Experience</p>
          </div>
          <div className={styles.studentsImg}>
            <img
              src="./images/stu-2.png"
              alt="Group of Students"
            />
          </div>
        </div>
      </div>

      <div className={styles.rightSide}>
        <span className={styles.aboutTag}>ABOUT US</span>
        <h2 className={styles.heading}>
         History of {' '}
          <span className={styles.highlight}>MSMS</span>
        </h2>
        <p className={styles.desc}>
         Established with a passion for transforming education, Morning Star Matriculation School (MSMS) has been a beacon of academic excellence and holistic development since its inception in 1994 . From humble beginnings, MSMS has evolved into one of the most reputed institutions in the region, committed to nurturing young minds with strong moral values, critical thinking, and creative problem-solving skills. Rooted in tradition but future-focused, MSMS continues to illuminate the path for thousands of students year after year.
        </p>
        <div className={styles.missions}>
          <div>
            <h4>OUR MISSION:</h4>
            <p>
              Suspendisse ultrice gravida dictum fusce placerat ultricies integer
              quis auctor elit sed vulputate mi sit.
            </p>
          </div>
          <div>
            <h4>OUR VISSION:</h4>
            <p>
            To provide a safe, nurturing, and intellectually stimulating environment where students thrive through a balanced curriculum, dedicated educators, and values-based learning. 
            </p>
          </div>
        </div>
        <button className={styles.btn}>Admission Open ➔</button>
      </div>
    </section>
  );
};

export default AboutUs;
