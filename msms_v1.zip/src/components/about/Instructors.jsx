import React from 'react';
import styles from './Instructors.module.css';
import { FaArrowLeft, FaArrowRight, FaShareAlt, FaBook  } from 'react-icons/fa';

const instructors = [
  {
    name: "Micheal Hammond",
    role: "Teacher",
    img: "./images/teacher-2.jpg",
  },
  {
    name: "Cheryl Curry",
    role: "Teacher",
    img: "./images/teacher-3.jpg",
  },
  {
    name: "Willie Diaz",
    role: "Teacher",
    img: "./images/teacher-1.jpg",
  },
  {
    name: "Jimmy Sifuentes",
    role: "Teacher",
    img: "./images/teacher-4.jpg",
  },
];

const Instructors = () => {
  return (
    <section className={styles.instructorSection}>
 <div className={styles.header}>
  <div>
    <span className={styles.subtitle}>
      <FaBook className={styles.bookIcon} /> TEACHER
    </span>
    <h2 className={styles.title}>Meet Our Instructor</h2>
  </div>

        <div className={styles.navButtons}>
          <button><FaArrowLeft /></button>
          <button><FaArrowRight /></button>
        </div>
      </div>

      <div className={styles.cardContainer}>
        {instructors.map((inst, index) => (
          <div key={index} className={styles.card}>
            <div className={styles.imgWrapper}>
              <img src={inst.img} alt={inst.name} />
              <button className={styles.shareBtn}><FaShareAlt /></button>
            </div>
            <div className={styles.cardContent}>
              <h4>{inst.name}</h4>
              <span className={styles.role}>{inst.role}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Instructors;
