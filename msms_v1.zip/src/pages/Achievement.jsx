import React from 'react';
import Header from '../components/Header';
import AchievetHero from '../components/achievements/AchieveHero';
// import Contactus from '../components/contact/ContactUs';
import Footer from '../components/Footer';
import AcademicAchievements from '../components/achievements/AcademicAchievements';
import InstagramReels from '../components/achievements/InstagramReels';
const Achieve = () => {
  return (
    <>
      <Header />
<AchievetHero/>
{/* <Contactus/> */}
     <AcademicAchievements/>
<InstagramReels/>
<Footer/>
</>
  );
};

export default Achieve;