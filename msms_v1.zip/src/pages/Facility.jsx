import React from 'react';
import Header from '../components/Header';
// import ContactHero from '../components/contact/ContactHero';
// import Contactus from '../components/contact/ContactUs';
import Footer from '../components/Footer';
import FacilityHero from '../components/facilities/FacilityHero';
import FacilitiesSection from '../components/facilities/FacilitiesSection';
import WorkProcess from '../components/facilities/WorkProcess';
const Facility = () => {
  return (
    <>
      <Header />
<FacilityHero/>
<FacilitiesSection/>
      <WorkProcess/>
{/* <Contactus/> */}
<Footer/>
</>
  );
};

export default Facility;