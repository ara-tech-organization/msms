import React from 'react';
import Header from '../components/Header';
import GalleryHero from '../components/gallery/GalleryHero';
import GalleryPics from '../components/gallery/GalleryPics';
import Footer from '../components/Footer';

const Gallery = () => {
  return (
    <>
      <Header />
<GalleryHero/>
<GalleryPics/>
<Footer/>
</>
  );
};

export default Gallery;