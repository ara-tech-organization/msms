import React from 'react';
import Header from '../components/Header';
import HeroSection from '../components/home/HeroSection';
import AboutSection from '../components/home/AboutSection';
import ChooseUs from '../components/home/ChooseUs';
import Footer from '../components/Footer'
import Counter from '../components/home/Counter';
import Facilities from '../components/home/StaffPortalSection';

const Home = () => {
  return (
    <>
      <Header />
      <main>
       <HeroSection/>
       <AboutSection/>
       <Facilities/>
       <ChooseUs/>
       <Counter/>
       <Footer/>
      </main>
    </>
  );
};

export default Home;
