import React from 'react';
import Header from '../components/Header';
import ContactHero from '../components/contact/ContactHero';
import Contactus from '../components/contact/ContactUs';
import Footer from '../components/Footer';

const Contact = () => {
  return (
    <>
      <Header />
<ContactHero/>
<Contactus/>
<Footer/>
</>
  );
};

export default Contact;